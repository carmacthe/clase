
package com.demo.restaurante;

/**
 *
 * @author Henry
 */
public class Orden {
    int clienteId;

    public Orden(int clienteId) {
        this.clienteId = clienteId;
    }
    
}
